server {
    server_name dhanman.com www.dhanman.com;

    root /var/www/prod/frontend;  # Path to the production React app

    location / {
        try_files $uri /index.html;
    }

    # Optional: Add custom error pages or other settings as needed
    error_page 404 /404.html;
    location = /404.html {
        root /var/www/prod/frontend;
    }

    # Optional: Enable Gzip compression for better performance
    gzip on;
    gzip_types text/css application/javascript text/javascript application/x-javascript;
    gzip_min_length 1000;
    gzip_proxied any;

    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/dhanman.com/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/dhanman.com/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot


}
server {
    if ($host = www.dhanman.com) {
        return 301 https://$host$request_uri;
    } # managed by Certbot


    if ($host = dhanman.com) {
        return 301 https://$host$request_uri;
    } # managed by Certbot


    listen 80;
    server_name dhanman.com www.dhanman.com;
    return 404; # managed by Certbot




}