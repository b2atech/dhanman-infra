# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name prod.common.dhanman.com;
    return 301 https://$host$request_uri;
}

# Secure HTTPS server
server {
    listen 443 ssl;
    server_name prod.common.dhanman.com;

    ssl_certificate /etc/letsencrypt/live/prod.common.dhanman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/prod.common.dhanman.com/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;

    location / {
        proxy_pass http://127.0.0.1:5100;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
