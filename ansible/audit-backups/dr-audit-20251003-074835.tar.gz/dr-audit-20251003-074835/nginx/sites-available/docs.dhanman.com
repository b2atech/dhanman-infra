server {
    server_name docs.dhanman.com;

    root /var/www/dhanman-docs-site;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    # Optional: Enable gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/docs.dhanman.com/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/docs.dhanman.com/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot

}
server {
    if ($host = docs.dhanman.com) {
        return 301 https://$host$request_uri;
    } # managed by Certbot


    listen 80;
    server_name docs.dhanman.com;
    return 404; # managed by Certbot


}