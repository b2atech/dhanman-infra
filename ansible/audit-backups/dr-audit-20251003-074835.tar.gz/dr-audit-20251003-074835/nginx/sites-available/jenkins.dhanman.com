map $http_upgrade $connection_upgrade {
    default upgrade;
    ''      close;
}

server {
    listen 80;
    server_name jenkins.dhanman.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name jenkins.dhanman.com;

    ssl_certificate /etc/letsencrypt/live/jenkins.dhanman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/jenkins.dhanman.com/privkey.pem;

    location /userContent {
        root /var/lib/jenkins/;
        sendfile on;
    }

    location / {
        proxy_pass http://localhost:9081;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;

        proxy_connect_timeout      90;
        proxy_send_timeout         90;
        proxy_read_timeout         90;
        client_max_body_size       10m;
        client_body_buffer_size    128k;
    }
}
