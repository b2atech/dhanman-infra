# Redirect all HTTP to HTTPS
server {
    listen 80;
    server_name qa.inventory.dhanman.com;
    return 301 https://$host$request_uri;
}

# Serve app securely over HTTPS
server {
    listen 443 ssl;
    server_name qa.inventory.dhanman.com;

    ssl_certificate /etc/letsencrypt/live/qa.inventory.dhanman.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/qa.inventory.dhanman.com/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;

    # Add browser security headers (optional but good)
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;

    location / {
        proxy_pass http://127.0.0.1:5202;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
