server {
    server_name dbtula.dhanman.com;

    root /var/www/dbtula-site;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/dbtula.dhanman.com/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/dbtula.dhanman.com/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot

}
server {
    if ($host = dbtula.dhanman.com) {
        return 301 https://$host$request_uri;
    } # managed by Certbot


    listen 80;
    server_name dbtula.dhanman.com;
    return 404; # managed by Certbot


}